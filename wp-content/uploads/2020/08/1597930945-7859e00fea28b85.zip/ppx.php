<?php
header("Access-Control-Allow-Origin:*");
header('Content-type: application/json');
!empty($_REQUEST['url']) ? $url = $_REQUEST['url'] : exit(json_encode(['code'=>202, "msg"=>"缺失参数"],JSON_UNESCAPED_UNICODE));
$api = file_get_contents('https://h5.pipix.com/bds/webapi/item/detail/?item_id='.id($url).'&source=share');
$data = json_decode($api,true);
if($data){
        $value = array('code'=>200,'msg'=>'成功','name'=>$data['data']['item']['author']['name'],'title'=>$data['data']['item']['content'],'pic'=>$data['data']['item']['origin_video_download']['cover_image']['url_list'][0]['url'],'url'=>$data['data']['item']['origin_video_download']['url_list'][0]['url']);
}else{
        $value = array('code'=>202,'msg'=>'获取失败');
}
echo json_encode($value,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);

function id($url){ //获取真实地址并截取ID
        $api = get_headers($url,1);
        $pid  = explode("/item/",$api['location']);
        $id  = explode("?app_id",$pid[1]);
        return $id[0];
}